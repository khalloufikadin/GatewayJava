/** 
 * Makes an individual card with a print, equals, and compare to option.
 * Kadin Khalloufi
 * 653EDA/kkhallo1
 * 4/13/23
 */
 
public class Card {
   // Defines the two attributes rank and suit
   private String[] suits = new String[] {"Clubs", "Diamonds", "Hearts",
      "Spades"};
   private String[] ranks = new String[] {"Ace", "2", "3", "4", "5", "6", 
      "7", "8", "9", "10", "Jack", "Queen", "King"};
   
   // Defines the values of user input
   private int rank;
   private int suit;
   
   /** 
    * Inputs the rank and suit value into the card.
    * @param rank The number for rank
    * @param suit The number for suit
    */
   public Card(int rank, int suit) {
      // Checks if the input is within the accepted bounds
      if ((suit > 0 && suit < 5) && (rank > 0 && rank < 14)) {
         
         // Assigns the input into the rank and suit variables
         this.rank = rank;
         this.suit = suit;
      }
      
      // Doesn't meet criteria and assigns 0
      else {
         this.rank = 0;
         this.suit = 0;
      }
   }
   
   /** 
    * Gets the rank number value.
    * @return rank The number of the card
    */
   public int getRank() { 
      
      // Returns the number of the card
      return rank;
   }
   
   /** 
    * Gets the suit number value.
    * @return suit The number of the card
    */
   public int getSuit() {
   
      // Returns the suit of the card
      return suit;
   }
   
   /** 
    * Converts the card to a readable string.
    * @return line The suit and rank of the card
    */
   @Override
   public String toString() {
      
      // Makes a blank line
      String line = "";
      
      // If the criteria was not met then gives invalid line
      if (rank == 0 || suit == 0) {
         line += "Invalid Card Value";
      }
      
      // Makes the line in rank of suit form
      else {
         line += ranks[rank - 1] + " of " + suits[suit - 1]; 
      }
      
      // Returns the line
      return line;
   }
   
   /** 
    * Checks to see if two cards are equal in suit and rank values.
    * @param other The object card that is being checked
    * @return equal The boolean if the cards are equal or not
    */
   @Override
   public boolean equals(Object other) {
      
      // Establishes the value as false
      boolean equal = false;
      
      // Checks if the object is a card or not
      if (other instanceof Card) {
         
         // Checks if the rank and suit values are the same
         if (rank == (((Card) other).getRank()) && 
            suit == ((Card) other).getSuit()) {
            
            // Sets the boolean to true if criteria is met
            equal = true;
         }
      }
      
      // Returns the boolean
      return equal;
   }
   
   /** * Compare this Card with the specified otherCard for order. 
   * @param otherCard the other Card object to be compared. 
   * @return a negative integer, zero, or a positive integer as 
   * this object is less than, equal to, or greater than the otherCard. 
   */ 
   public int compareTo(Card otherCard) { 
      
      // Checks to see which suit value is higher
      int compare = suit - otherCard.getSuit();
      
      // If they are the same suit
      if (compare == 0) {
         
         // Checks the rank values
         compare = rank - otherCard.getRank();
      }
      
      // Returns the compare value
      return compare; 
   }

}